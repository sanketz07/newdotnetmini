﻿using System;
using System.Collections.Generic;
using System.Linq;
using Student_Management_System.Models;
using Student_Management_System.DataBaseContext;
using System.Text.RegularExpressions;

namespace Student_Management_System.Controllers
{
     class UserController
    {
        string studentName = "";
        string studentEmail = "";
        string studentPassword = "";
        string studentDOB = "";

        //  userLogin();
        public void userLogin()
        {
            Console.WriteLine("-------User's Login -------");
            Console.Write("Email : ");
            String email = Console.ReadLine();
            Console.Write("Password : ");
            Console.ForegroundColor = ConsoleColor.Black;
            String password = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("---------------------------");


            SmsDbContext dbctx = new SmsDbContext();
            List<User> userList = dbctx.Users.ToList();
            User searchedUser = new User();

            foreach (User u in userList)
            {
                if (u.email == email && u.password == password)
                    searchedUser = u;
            }

            if (searchedUser != null)
            {
                if (searchedUser.role == "Student")
                {
                    StudentController studentControl = new StudentController();
                    studentControl.StudentRole(searchedUser);
                }
                else if (searchedUser.role == "Admin")
                {
                    AdminController.AdminRole(email, password);
                }
                else Console.WriteLine("Invalid Credentials !!!");
            }
            else Console.WriteLine("User Not Found !!!");

        }

        public void userRegistration()
        {
            string studentName = "";
            string studentEmail = "";
            string studentPassword = "";
            string studentMobileNumber = "";
            string studentDOB = "";
            //startss
            Console.WriteLine("------- Student's Registration ------");
            ValidateName();

            void ValidateName()
            {

                Console.Write("First Name: ");

                studentName = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(studentName) || studentName.All(char.IsDigit))
                {
                    Console.WriteLine("Please enter valid name");
                    ValidateName();
                }

            }

            //Console.Write("Name : ");
            //String studentName = Console.ReadLine();

            InputEmail();
            void InputEmail()
            {
                Console.Write("Email id: ");

                studentEmail = Console.ReadLine();




                string pattern = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";


                //if (Regex.IsMatch(email, pattern))

                //if email is invalid
                if (!Regex.IsMatch(studentEmail, pattern))
                {
                    Console.WriteLine(studentEmail + " not a valid Email address. Please enter correct email \n ");
                    InputEmail();
                }

            }

            validatePassword();
            void validatePassword()
            {

                Console.Write("Password: ");
                Console.ForegroundColor = ConsoleColor.Black;
                 studentPassword = Console.ReadLine();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("Confirm Password: ");
                Console.ForegroundColor = ConsoleColor.Black;
                string studentPassword1 = Console.ReadLine();
                Console.ForegroundColor = ConsoleColor.White;


                Console.ForegroundColor = ConsoleColor.White;

                if (string.IsNullOrWhiteSpace(studentPassword) || studentPassword1.Length < 8)
                {
                    Console.WriteLine("\n Please enter password with length.");
                    validatePassword();
                }

                else if (studentPassword == studentPassword1)
                {
                    Console.WriteLine("------------------------------------------");
                    Console.WriteLine("password matched!!!");
                    Console.WriteLine("------------------------------------------");

                }
                else if (studentPassword != studentPassword1)
                {
                    Console.WriteLine("------------------------------------------");
                    Console.WriteLine("password doesnt match !!!");
                    Console.WriteLine("------------------------------------------");
                    validatePassword();
                }
            }

            ValidateContact();

            Console.WriteLine();

            void ValidateContact()
            {
                Console.Write("Mobile Number: ");

               string studentMobileNumber1 = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(studentMobileNumber1) && studentMobileNumber1.Length == 10)
                {
                    studentMobileNumber = (studentMobileNumber1);
                    //Regex.IsMatch(phone, @"\(?\d{3}\)?-? *\d{3}-? *-?\d{4}",
                    //                     RegexOptions.IgnoreCase);
                }

                else
                {
                    Console.WriteLine("Please enter valid contact");
                    ValidateContact();

                }
            }
            


            ValidateDob();

            void ValidateDob()
            {
                Console.WriteLine("Date Of Birth in the format of MM/DD/YYYY:");
                studentDOB = Console.ReadLine();

                if (!string.IsNullOrWhiteSpace(studentDOB))
                {

                    studentDOB = (studentDOB);
                }
                else
                {
                    Console.WriteLine("Please enter valid Date of Birth");
                    ValidateDob();
                }
            }



            



            //endss
            //Console.WriteLine("------- Student's Registration ------");
            //  Console.Write("Name : ");
            //   String studentName = Console.ReadLine();
            //  Console.Write("Email : ");
            //  String studentEmail = Console.ReadLine();

            //  Console.Write("Password : ");
            //  Console.ForegroundColor = ConsoleColor.Black;
            //  String studentPassword = Console.ReadLine();
            // Console.ForegroundColor = ConsoleColor.White;
            // Console.Write("Confirm Password : ");
            // Console.ForegroundColor = ConsoleColor.Black;
            //  String studentPassword1 = Console.ReadLine();
            // Console.ForegroundColor = ConsoleColor.White;
            //sanketstart
          //  Console.Write("Please Enter the Mobile Number : ");
            //    String studentMobileNumber = Console.ReadLine();
                Console.Write("Please Enter the Gender : ");
                String studentGender = Console.ReadLine();
                Console.Write("Please Enter the Address : ");
                String studnetAddress = Console.ReadLine();
            //    Console.Write("Please Enter the Date of Birth in Format of MM/DD/YYYY : ");
           //     String studentDOB = (Console.ReadLine());

                //sanket end
                Console.Write("Course : ");
                String course = Console.ReadLine();
                Console.WriteLine("-------------------------------------");

            
                SmsDbContext ctx = new SmsDbContext();

                Student stud = new Student();
                User user = new User();

                user.name = studentName;
                user.email = studentEmail;
                user.password = studentPassword;
                //sanketstart
                user.MobileNumber = studentMobileNumber;
                user.Gender = studentGender;

                user.Address = studnetAddress;
                user.DOB = studentDOB;
                //sanketend
                user.role = "Student";

                stud.course = course;
                user.student = stud;

                ctx.Users.Add(user);
             //   ctx.Students.Add(stud);
                ctx.SaveChanges();

                Console.WriteLine("-----------------------------");
                Console.WriteLine(studentName + " registered !!!");
                Console.WriteLine("-----------------------------");
               // userLogin();
            }


        }
    }

