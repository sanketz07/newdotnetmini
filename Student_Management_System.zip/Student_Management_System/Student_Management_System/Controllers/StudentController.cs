﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Student_Management_System.DataBaseContext;
using Student_Management_System.Models;

namespace Student_Management_System.Controllers
{
    public class StudentController
    {
        internal void StudentRole(User user)
        {
            
            Console.WriteLine("-------------------------------");
            Console.WriteLine(" Welcome " + user.name + "  !!! ");
            Console.WriteLine(" You've Logged in as a Student !");

            Boolean flag = true;
            while (flag)
            {

            Console.WriteLine("-----------------------------");

            Console.WriteLine("1-showDetails\n2-updateDetails\n3-Logout");
            
            Console.WriteLine("-----------------------------");

                int option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        Console.WriteLine("Show Details");
                        showDetails(user);
                        break;

                    case 2:
                        Console.WriteLine("Update Details");
                        updateDetails(user);
                        break;

                    case 3:
                        Console.WriteLine("Logout !!!");
                        flag = false;
                        break;

                }

            }
        }

        private void updateDetails(User user)
        { 
            SmsDbContext dbctx = new SmsDbContext();
            Console.WriteLine("Do you want to update password ? Y/N?");
            string choice = Console.ReadLine();

            if (choice == "Y")
            {
                Console.Write("Please Mention Updated Password:");
                string UpdatedPassword = Console.ReadLine();
                Student student1 = dbctx.Students.Find(user.userID);
                user.password = UpdatedPassword;

                dbctx.Students.Update(student1);
                dbctx.Users.Update(user);
                dbctx.SaveChanges();


            }
            else if(choice=="N"){
                Console.WriteLine("Do you want to update your cource? Y/N?");
                string choice2 = Console.ReadLine();
                if (choice2 == "Y")
                {
                   
                    Console.Write("Please Mention Updated Course:");
                    string UpdatedCourse = Console.ReadLine();
                    Student student = dbctx.Students.Find(user.userID);
                    student.course = UpdatedCourse;
                    dbctx.Users.Update(user);
                    dbctx.SaveChanges();
                }
                else if(choice2=="N")
                {
                    Console.WriteLine("-----------------------------");
                    Console.WriteLine("thank  you!!");
                }
                else
                {
                    Console.WriteLine("PLEASE ENTER CORRECT CHOISE!!");
                }

            }

            else
            {
                Console.WriteLine("PLEASE ENTER CORRECT CHOISE!!");
            }
            //Console.Write("Please Mention Updated Password:");
            //string UpdatedPassword = Console.ReadLine();





            //  user.password = UpdatedPassword;

            //student.course = UpdatedCourse;
            //dbctx.Students.Update(student);
            //dbctx.Users.Update(user);
            //dbctx.SaveChanges();

        }

        private void showDetails(User user)
        {
            SmsDbContext dbctx = new SmsDbContext();

            Student stu = dbctx.Students.Find(user.userID);

            Console.WriteLine($"{user.userID}  {user.name}  {user.email}    {user.role}  {stu.course}  {user.Address}  {user.DOB}  {user.MobileNumber}");
            
        }


    }

}
