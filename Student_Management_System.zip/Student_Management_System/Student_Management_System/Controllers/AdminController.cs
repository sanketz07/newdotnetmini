﻿using Student_Management_System.DataBaseContext;
using Student_Management_System.Models;
using System.Collections.Generic;
using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace Student_Management_System.Controllers
{
    class AdminController
    {
        public static void AdminRole(String email, String password)
        {
            SmsDbContext ctx = new SmsDbContext();
            var admn = from u in ctx.Users
                                    select u;
            User user = new User();
            foreach (var item in admn)
            {
                if (item.email == email) user = item;
            }
            Console.WriteLine("-----------------------------");
            Console.WriteLine(" Welcome " + user.name + " !!!");
            Console.WriteLine(" You've Logged in as a Admin !");
            Boolean flag = true;
            while (flag)
            {
                Console.WriteLine("-----------------------------");


                Console.WriteLine("1-Add_Student\n2-Delete_Student\n3-Update_Student\n4-Show_All_Students\n5-Logout");
                Console.WriteLine("-----------------------------");

                int option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        addStudent();
                        break;

                    case 2:
                        deleteStudent();
                        break;

                    case 3:
                        updateStudent();
                        break;

                    case 4:
                        showAll();
                        break;

                    case 5:
                        Console.WriteLine("Logout !!!");
                        Console.WriteLine("==============================");
                        flag = false;
                        break;

                }
            }
        }

      
        private static void showAll()
        {
            Console.WriteLine("--------- All Users Data ---------");

            SmsDbContext ctx = new SmsDbContext();
            List<User> usrs = ctx.Users.ToList();
            List<Student> stds = ctx.Students.ToList();

            foreach (User u in usrs)
            {
                foreach (Student s in stds)
                {
                    if (s.studentId == u.userID)
                    {
                        Console.WriteLine($"{u.userID} {u.name} {u.email} {s.course} {u.MobileNumber}  {u.Gender} {u.Address}  {u.DOB}");
                    }
                }

            }

            Console.WriteLine("----------------------------------");
        }

        private static void updateStudent()
        {
            Console.WriteLine("------ Update Student ------");
            Console.WriteLine("Enter ID :");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("New Password :");
            String newPassword = Console.ReadLine();
            //starr
            Console.Write("Please Enter the Mobile Number : ");
            String newstudentMobileNumber = Console.ReadLine();
            Console.Write("Please Enter the Address : ");
            String newstudnetAddress = Console.ReadLine();
            //end
            Console.Write("New Course :");
            String newCourse = Console.ReadLine();

            SmsDbContext ctx = new();
            User usr = ctx.Users.Find(id);
            Student stud = ctx.Students.Find(id);
            usr.MobileNumber = newstudentMobileNumber;
            usr.Address = newstudnetAddress;
            usr.password = newPassword;
            stud.course = newCourse;

            ctx.Students.Update(stud);
            ctx.Users.Update(usr);
            ctx.SaveChanges();

            Console.WriteLine("------------------------");
            Console.WriteLine(usr.name + " updated !!!!");
            Console.WriteLine("------------------------");
        }

        private static void deleteStudent()
        {
            Console.WriteLine("------ Delete Student ------");
            Console.Write("Enter ID :");
            // int id = Convert.ToInt32(Console.ReadLine());
            int userID = Convert.ToInt32(Console.ReadLine());

            SmsDbContext ctx = new();
            User usr = ctx.Users.Find(userID);
           Student stud = ctx.Students.Find(userID);

            ctx.Students.Remove(stud);
            ctx.Users.Remove(usr);
            ctx.SaveChanges();

            Console.WriteLine("-----------------------------");
            Console.WriteLine(usr.name + "  Student  Deleted  ");
            Console.WriteLine("-----------------------------");
        }

        private static void addStudent()
        {
            Console.WriteLine("------- Add Student ------");
            Console.Write("Name : ");
            String studentName = Console.ReadLine();
            Console.Write("Email : ");
            String studentEmail = Console.ReadLine();
            Console.Write("Password : ");
            String studentPassword = Console.ReadLine();
            //sanket start
            Console.Write("Please Enter the Mobile Number : ");
            String studentMobileNumber = Console.ReadLine();
            Console.Write("Please Enter the Gender : ");
            String studentGender = Console.ReadLine();
            Console.Write("Please Enter the Address : ");
            String studnetAddress = Console.ReadLine();
            Console.Write("Please Enter the Date of Birth in Format of MM/DD/YYYY : ");
            String studentDOB = (Console.ReadLine());
            //sanket end

            Console.Write("Course : ");
            String course = Console.ReadLine();
            Console.WriteLine("--------------------------");


            SmsDbContext ctx = new SmsDbContext();

            Student stud = new Student();
            User user = new User();

            user.name = studentName;
            user.email = studentEmail;
            user.password = studentPassword;
            user.role = "Student";
            //start
            user.MobileNumber = studentMobileNumber;
            user.Gender = studentGender;

            user.Address = studnetAddress;
            user.DOB = studentDOB;
            //end
            stud.course = course;

            user.student = stud;
            ctx.Users.Add(user);
            ctx.Students.Add(stud);

            ctx.SaveChanges();

            Console.WriteLine("-----------------------------");
            Console.WriteLine(studentName + " Added to SMS !!!");
            Console.WriteLine("-----------------------------");
        }

        public void AddAdmin()
        {
            SmsDbContext ctx = new SmsDbContext();
            Student NA = new Student();
            User admn = new User();
            admn.name = "admin";
            admn.email = "admin@gmail.com";
            admn.password = "12345";
            admn.role = "Admin";
            admn.MobileNumber="8888888888";
            admn.Gender = "male";
            admn.Address = "pune";
            admn.DOB = "01/01/1995";
            NA.course = "-";
            admn.student = NA;
            ctx.Users.Add(admn);
            ctx.Students.Add(NA);
            ctx.SaveChanges();
        }
    }
}