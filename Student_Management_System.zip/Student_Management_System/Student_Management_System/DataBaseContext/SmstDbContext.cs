﻿using Student_Management_System.Models;
using Microsoft.EntityFrameworkCore;


namespace Student_Management_System.DataBaseContext
{
    class SmsDbContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=SANKETZ-VD\SQL2017; DataBase=SMSDATA3; User Id=sa; Password=cybage@123456;");
        }

        public virtual DbSet<User> Users { get; set; }

        public virtual DbSet<Student> Students { get; set; }

    }
}
